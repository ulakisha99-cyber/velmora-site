var DEL={UK:[3,5],EU:[5,8]};
function addDays(d,n){var x=new Date(d);x.setDate(x.getDate()+n);return x}
function fmt(d){return d.toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'})}
function window_(lead,reg,today){return{early:addDays(today,lead+DEL[reg][0]),late:addDays(today,lead+DEL[reg][1])}}
function status(w,need){
  if(!need)return{k:'info',t:'Arrives between '+fmt(w.early)+' and '+fmt(w.late)+' if you order today.'};
  if(w.late<=need)return{k:'ok',t:'Arrives by '+fmt(w.late)+' at the latest. In time.'};
  if(w.early<=need)return{k:'maybe',t:'May arrive in time: between '+fmt(w.early)+' and '+fmt(w.late)+'. Not guaranteed.'};
  return{k:'no',t:'Will not arrive by '+fmt(need)+'. Earliest is '+fmt(w.early)+'.'};
}
function recommend(P,q){
  var min=Math.min.apply(null,P.map(function(p){return p.price_gbp}));
  if(q.need&&q.need<new Date(q.today.toDateString()))return{msg:'That date has passed. Please choose a later date.',items:[]};
  if(q.budget!=null&&q.budget<min)return{msg:'Our lowest price is £'+min+'. I have nothing under that.',items:[]};
  var rank={ok:0,maybe:1,info:1,no:2};
  var items=P.filter(function(p){return p.occasions.indexOf(q.occ)>-1&&(p.made_to_order||p.in_stock)&&(q.budget==null||p.price_gbp<=q.budget)})
   .map(function(p){var w=window_(p.lead_time_days,q.reg,q.today);return{p:p,s:status(w,q.need)}})
   .sort(function(a,b){return rank[a.s.k]-rank[b.s.k]||a.p.price_gbp-b.p.price_gbp});
  if(!items.length)return{msg:'I do not have a piece for that occasion and budget. Try a higher budget or another occasion.',items:[]};
  if(q.need&&items.every(function(i){return i.s.k==='no'}))return{msg:'None of these arrive by your date. I do not want to promise what we cannot meet. Ready-to-ship pieces are the fastest.',items:items.slice(0,6)};
  return{msg:items.length+' piece'+(items.length>1?'s':'')+' found. Dates are estimates if you order today.',items:items.slice(0,6)};
}
if(typeof module!=='undefined')module.exports={recommend:recommend,status:status,window_:window_};
if(typeof document!=='undefined'){
 var sf=document.getElementById('sf');
 if(sf)sf.addEventListener('submit',function(ev){ev.preventDefault();
  var n=document.getElementById('need').value,b=document.getElementById('bud').value;
  var r=recommend(window.PRODUCTS,{occ:document.getElementById('occ').value,reg:document.getElementById('reg').value,need:n?new Date(n+'T00:00:00'):null,budget:b===''?null:Number(b),today:new Date()});
  var box=document.getElementById('res');box.textContent='';
  var m=document.createElement('p');m.textContent=r.msg;box.appendChild(m);
  var g=document.createElement('div');g.className='grid';
  r.items.forEach(function(i){var a=document.createElement('a');a.className='card';a.href='/products/'+i.p.id.toLowerCase()+'.html';
   [[i.p.name+', '+i.p.colours[0],'n'],[i.p.fabric+' · £'+i.p.price_gbp,'m'],[i.s.t,'m s-'+i.s.k]].forEach(function(x){var s=document.createElement('span');s.className=x[1];s.textContent=x[0];a.appendChild(s)});g.appendChild(a)});
  box.appendChild(g)});
 var df=document.getElementById('df');
 if(df)df.addEventListener('submit',function(ev){ev.preventDefault();
  var n=document.getElementById('need').value,now=new Date();
  var out=document.getElementById('dres');
  if(n&&new Date(n+'T00:00:00')<new Date(now.toDateString())){out.textContent='That date has passed. Please choose a later date.';return}
  out.textContent=status(window_(Number(df.dataset.lead),document.getElementById('reg').value,now),n?new Date(n+'T00:00:00'):null).t});
}
